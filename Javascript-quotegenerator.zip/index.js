const quoteBtn = document.querySelector("button");
const quoteText = document.querySelector(".quote");
const authorName = document.querySelector(".author .name");
const soundBtn = document.querySelector(".sound");
const copyBtn = document.querySelector(".copy");
const twitterBtn = document.querySelector(".twitter");

function randomQuote(){
    //fetch api: fetch the random quote from API
    fetch("http://api.quotable.io/random")
    .then((res) =>res.json())
    .then((result) =>{
        quoteText.innerText = result.content;
        authorName.innerText = result.author;
    });
}
quoteBtn.addEventListener("click",randomQuote);

soundBtn.addEventListener("click",() =>{
    let utterance = new SpeechSynthesisUtterance(`${quoteText.innerText} by ${authorName.innerText}`);
    speechSynthesis.speak(utterance);
});

twitterBtn.addEventListener("click",() =>{
    let tweetUrl = `https://twitter.com/intent/tweet?=${quoteText.innerText}`;
    window.open(tweetUrl,"_blank");
});

copyBtn.addEventListener("click",() =>{
    navigator.clipboard.writeText(quoteText.innerText);
});
